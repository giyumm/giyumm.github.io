//EX13: returns the greatest among the given two numbers 
function GreatestNumber(x,y) {
   if (x>y){
         return x
   }
   else{
         return y
     }
  }
  console.log(GreatestNumber(2,25));

  //EX10:checks whether two given numbers are equal or not
  function Equalcheck(a,b){
   if (a===b){
    return true;
 }
    else{
    return false;
   }
}
console.log(Equalcheck(9,6));

//EX3:finds area of circle by given radius
function CircleArea(r){
  pi=3.14
  area=pi*(r**2)
  return area
}
console.log(CircleArea(5));


   

    

